<!doctype html>
<html class="no-js" lang=""> 

<head>
  <meta charset="utf-8">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>VIVA</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/flexslider.css">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/responsive.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

</head>

  <body>

    <!-- Header Section -->
        <?php include_once('inc/header.php'); ?>
    <!-- Header Section --> 
    <section class="section" id="author">
      <div class="container">
        <div class="row center-content">
          <div class="page-header">
            <h4>ชำระเงิน</h4>
          </div>
  
        </div>
      </div>
    </section>

              <!-- footer section -->
        <?php include_once('inc/footer.php'); ?>
        <?php include_once('inc/footer-script.php');?>
        
  </body>
</html>